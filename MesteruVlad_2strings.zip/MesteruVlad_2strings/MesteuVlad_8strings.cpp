#include <iostream>
#include <string.h>
#include <stdio.h>
using namespace std;

int main()
{
    char c[100];
    cout<<"Introduceti textul: ";
    fgets(c, 100, stdin);
    for(int i=0;i<(int)strlen(c);i++)
    {
        switch(c[i])
        {
            case 'a': c[i]='c';
                break;
            case 'b': c[i]='e';
                break;
            case 'c': c[i]='g';
                break;
            case 'd': c[i]='i';
                break;
            case 'e': c[i]='k';
                break;
            case 'f': c[i]='m';
                break;
            case 'g': c[i]='o';
                break;
            case 'h': c[i]='q';
                break;
            case 'i': c[i]='s';
                break;
            case 'j': c[i]='u';
                break;
            case 'k': c[i]='w';
                break;
            case 'l': c[i]='y';
                break;
            case 'm': c[i]='a';
                break;
            case 'n': c[i]='c';
                break;
            case 'o': c[i]='e';
                break;
            case 'p': c[i]='g';
                break;
            case 'q': c[i]='i';
                break;
            case 'r': c[i]='k';
                break;
            case 's': c[i]='m';
                break;
            case 't': c[i]='o';
                break;
            case 'u': c[i]='q';
                break;
            case 'v': c[i]='s';
                break;
            case 'w': c[i]='u';
                break;
            case 'x': c[i]='w';
                break;
            case 'y': c[i]='y';
                break;
            case 'z': c[i]='a';
                break;
        }
    }
    for(int i=0;i<(int)strlen(c);i++)
        cout<<c[i];
}
